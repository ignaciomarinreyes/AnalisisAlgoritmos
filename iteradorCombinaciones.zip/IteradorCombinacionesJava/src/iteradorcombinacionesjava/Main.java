package iteradorcombinacionesjava;

public class Main {

    public static void main(String[] args) {
        int contador = 0;
        int N = 5;  
        int[] combinacion;
        IteradorCombinaciones it = new IteradorCombinaciones(N);      
        while (! it.ultimaCombinacion()){
            combinacion = it.siguienteCombinacion();
            for (int i = 0; i < combinacion.length; i++) {
                System.out.print(combinacion[i] + " ");
            }
            System.out.println();
            contador++;
        }
        System.out.println(contador);
    }   
}
