package filegenerator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.ThreadLocalRandom;

public class FileGenerator {

    public static void main(String[] args) {
        String ruta = "C://Users//COCO//Documents//NetBeansProjects//"
                + "Pr3.Practica2//dist//fichVect.txt";   
        final int min = 0;
        final int max = 100;
        int size = ThreadLocalRandom.current().nextInt(1, max + 1);
        
        try {
            File fichero = new File(ruta);
            if (!fichero.exists()){
                fichero.createNewFile();
            }                
            BufferedWriter bw;
            bw = new BufferedWriter(new FileWriter(fichero));
            bw.write(String.valueOf(size));            
            for (int i = 0; i < size; i++){
                int n = ThreadLocalRandom.current().nextInt(min, max + 1);
                bw.newLine();
                bw.write(String.valueOf(n));
            }
            bw.close();
        }catch(IOException e){
             System.out.println(e.getMessage());
        }        
    }
    
}
