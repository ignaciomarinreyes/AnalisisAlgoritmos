package iteradorcombinacionesjava;

public class Main {

    public static void main(String[] args) {
        int[] combinacion;
        IteradorCombinaciones it = new IteradorCombinaciones(args.length);
        while (!it.ultimaCombinacion()) {
            combinacion = it.siguienteCombinacion();
            for (int i = 0; i < combinacion.length; i++) {
                if (combinacion[i] == 1) {
                    System.out.print(args[i] + " ");
                }
            }
            System.out.println();
        }
    }
}
