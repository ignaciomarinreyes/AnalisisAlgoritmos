package pr3java;

public class pr3java {
    
    public static void main(String[] args) {
        ParserArgs pargs = new ParserArgs(args); 
        pargs.parserArg();
    }    
}
