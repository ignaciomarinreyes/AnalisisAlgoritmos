package pr3.practica2;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

public final class ParserArgs {
    private final String[] args;
    
    public ParserArgs(String[] args){
        this.args = args;
        parserArg();
    }
    
    public void parserArg(){
        Options options = new Options();
        
        Option help = new Option("h", "help", false, "Display help usage");
        Option print = Option.builder("p")
                       .longOpt("print")
                       .hasArgs()
                       .desc("Print a message")
                       .build(); 
        Option read = Option.builder("r")
                       .longOpt("read")
                       .hasArg()
                       .desc("Read a file text")
                       .build();
        
        options.addOption(help);
        options.addOption(print);
        options.addOption(read);
                
        HelpFormatter formatter = new HelpFormatter();
        CommandLineParser parser = new DefaultParser();
        
        try {
            CommandLine cmd = parser.parse(options, args);
            if(cmd.hasOption("h")){
                formatter.printHelp( "java -jar *.jar [-[h|p String]]", options );
            }else if(cmd.hasOption("p")){
                String[] aux = cmd.getOptionValues("p");
                if (aux != null){ 
                    System.out.print("Se ha introducido:");
                    for (String string : aux) {
                        System.out.print(" " + string);
                    }                   
                }               
            }else if(cmd.hasOption("r")){
                String fich = cmd.getOptionValue("r");
                if (fich != null){
                    ReadFile fichero = new ReadFile(fich);
                    int[] vector = fichero.readFile();
                    for (int i : vector) {
                        System.out.println(i);
                    }
                }
            }else{
                formatter.printHelp( "java -jar *.jar [-[h|p String]]", options );
            }
        } catch (ParseException exp) {
            System.err.println( "Fallo de parseo: " + exp.getMessage() );
            formatter.printHelp( "java -jar *.jar [-[h|p String]]", options );
        }
    }
}
