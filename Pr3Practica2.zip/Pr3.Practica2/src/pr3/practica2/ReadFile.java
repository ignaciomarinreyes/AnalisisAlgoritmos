package pr3.practica2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public final class ReadFile {
    private final String fich;
    private String entero;
    public ReadFile(String fich){
        this.fich = fich;
    }
    
    public int[] readFile(){
        int[] vector = null;
        int i = 0;
        FileReader f;
        try {
            f = new FileReader(fich);
            BufferedReader b;
            b = new BufferedReader(f);
            vector = new int[Integer.parseInt(b.readLine())];
            while((entero = b.readLine()) != null) {
                vector[i] = Integer.parseInt(entero);
                i++;
            }   
            b.close();
        } catch (FileNotFoundException ex) {
            System.out.println("Fichero no encontrado: " + ex.getMessage());
        } catch (IOException ex){
            System.out.println("Fallo de IO: " + ex.getMessage());
        }
        return vector;
    }
}
