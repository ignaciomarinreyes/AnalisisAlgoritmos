package pr3.practica2;

import java.io.File;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

public final class ParserArgs {
    private final String[] args;
    private String scale;
    
    public ParserArgs(String[] args){
        this.args = args;
        parserArg();
    }
    
    public void parserArg(){
        Options options = new Options();
        
        Option help = new Option("h", "help", false, "Display help usage");
        Option printIn = new Option("di", "input", false, "Display input data");
        Option printOut = new Option("do", "output", false, "Display ouput data");
        Option addPol = new Option("a", "add", false, "Add all polynomials");
        Option printTime = Option.builder("dt")
                          .longOpt("time")
                          .hasArg()
                          .optionalArg(true)
                          .desc("Display taken time in seconds or (arg [ms | ns])")
                          .build();
        Option folder = Option.builder("f")
                       .longOpt("folder")
                       .hasArg()
                       .desc("Read vectors from a Folder")
                       .build();
        
        options.addOption(help);
        options.addOption(printIn);
        options.addOption(printOut);
        options.addOption(printTime);
        options.addOption(folder);
        options.addOption(addPol);
                
        HelpFormatter formatter = new HelpFormatter();
        CommandLineParser parser = new DefaultParser();
        
        try {
            CommandLine cmd = parser.parse(options, args);
            
            if(cmd.hasOption("h")){
                formatter.printHelp( "java -jar *.jar [-[h|di|do|dt [s|ms|ns]|r PathDir]]", options );
            } else if(cmd.hasOption("f")){
                String fich = cmd.getOptionValue("f");
                if (fich != null && new File("..\\..\\" + fich).exists()){
                    ReadFile fichero = new ReadFile(fich);
                    if (cmd.hasOption("a")){
                        float[][] vecAdd = fichero.readFolder();                        
                        AddPoly addP = new AddPoly(vecAdd, vecAdd[0].length);
                        addP.add();
                        if(cmd.hasOption("di")){
                            System.out.println("Start Matrix is : "); 
                            new SolveEquation(vecAdd, vecAdd.length).PrintMatrix();
                            System.out.println();
                        }
                        if(cmd.hasOption("do")){
                            System.out.print("Result is: ");
                            addP.printPoly();
                            System.out.println();
                        }
                        if(cmd.hasOption("dt")){
                            scale = cmd.getOptionValue("dt");
                            addP.printTime(scale);
                        }
                    }else{                        
                        if(new File("..\\..\\" + fich).isFile()){
                            float[] vec = fichero.readOneFile();
                            for (float a : vec) {
                                System.out.print(a + ",");
                            }
                        }else{
                            float[][] vector = fichero.readFolder();
                            SolveEquation resSolve = new SolveEquation(vector, vector.length);                        
                            if (resSolve.PerformOperation() == 1) resSolve.CheckConsistency(); 

                            if (cmd.hasOption("di")){
                                // Printing Start Matrix
                                System.out.println("Start Matrix is : "); 
                                new SolveEquation(vector, vector.length).PrintMatrix();
                                System.out.println();
                            }                                                

                            if (cmd.hasOption("do")){
                                // Printing Solutions(if exist) 
                                resSolve.PrintResult();
                                System.out.println();
                            }
                            if (cmd.hasOption("dt")){
                                scale = cmd.getOptionValue("dt");
                                resSolve.printTime(scale);
                            }  
                        }
                    } 
                }
            } else {
                formatter.printHelp( "java -jar *.jar [-[h|di|do|dt [s|ms|ns]|r PathDir]]", options );
            }
        } catch (ParseException exp) {
            System.err.println( "Fallo de parseo: " + exp.getMessage() );
            formatter.printHelp( "java -jar *.jar [-[h|di|do|dt [s|ms|ns]|r PathDir]]", options );
        }
    }
}
