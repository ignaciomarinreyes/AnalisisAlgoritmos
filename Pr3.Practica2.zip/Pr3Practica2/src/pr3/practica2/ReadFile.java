package pr3.practica2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public final class ReadFile {
    private final File fileVect;
    private String entero;
    private FileReader f;
    private BufferedReader b;
    private int i;
    
    public ReadFile(String fichS){        
        fileVect = new File("..\\..\\" + fichS);
        i = 0;
    }
    
    public float[] readOneFile(){
        float vec[] = null;          
        try {
            f = new FileReader(fileVect);
            b = new BufferedReader(f);
            vec = new float[Integer.parseInt(b.readLine())];
            while((entero = b.readLine()) != null){
                vec[i] = Integer.parseInt(entero);
                i++;
            }
        } catch (FileNotFoundException ex) {
            System.out.println("Fichero no encontrado: " + ex.getMessage());
        } catch (IOException ex){
            System.out.println("Fallo de IO: " + ex.getMessage());
        }   
        return vec;
    }
    public float[][] readFolder(){     
        File[] ficheros = fileVect.listFiles();
        float[][] vector = new float[ficheros.length][];        
        int j;
         
        for (File fich : ficheros) {  
            j = 0;
            try {
                f = new FileReader(fich);
                b = new BufferedReader(f);
                vector[i] = new float[Integer.parseInt(b.readLine())];
                
                while((entero = b.readLine()) != null) {
                    vector[i][j] = Integer.parseInt(entero);
                    j++;
                }
                b.close();
            } catch (FileNotFoundException ex) {
                System.out.println("Fichero no encontrado: " + ex.getMessage());
            } catch (IOException ex){
                System.out.println("Fallo de IO: " + ex.getMessage());
            }
            i++;
        }        
        return vector;
    }
}
