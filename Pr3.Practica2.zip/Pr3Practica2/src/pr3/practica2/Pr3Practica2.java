package pr3.practica2;

public class Pr3Practica2 {
    
    public static void main(String[] args) {
        ParserArgs parserArgs = new ParserArgs(args);              
    }    
}
