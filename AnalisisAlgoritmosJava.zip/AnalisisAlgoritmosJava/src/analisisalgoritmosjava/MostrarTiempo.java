package analisisalgoritmosjava;

class MostrarTiempo {

    public MostrarTiempo() {
        System.out.println("Mostrar Tiempo");
    }

}
