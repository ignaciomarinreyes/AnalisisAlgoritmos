package analisisalgoritmosjava;

class Ayuda {

    public Ayuda() {
        System.out.println("Ayuda");
    }

}
