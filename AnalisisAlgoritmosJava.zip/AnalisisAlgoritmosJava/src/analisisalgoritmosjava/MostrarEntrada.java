package analisisalgoritmosjava;

class MostrarEntrada {

    public MostrarEntrada() {
        System.out.println("Mostrar Entrada");
    }

}
