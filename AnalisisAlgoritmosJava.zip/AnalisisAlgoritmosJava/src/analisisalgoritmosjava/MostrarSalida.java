package analisisalgoritmosjava;


class MostrarSalida {

    public MostrarSalida() {
        System.out.println("Mostrar Salida");
    }

}
