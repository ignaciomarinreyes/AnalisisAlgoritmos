package analisisalgoritmosjava;

class LeerFichero {

    public LeerFichero() {
        System.out.println("LeerFichero");
    }

}
