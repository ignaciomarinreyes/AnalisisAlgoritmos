/* 
 * File:   main.cpp
 * Author: ignaciomarinreyes
 *
 * Created on 20 de noviembre de 2019, 21:05
 */

#include <iostream>
#include <stdlib.h>
#include "IteradorCombinaciones.h"
using namespace std;

int main(int argc, char** argv) {
    int* combinacion;
    IteradorCombinaciones it(argc - 1);
    while(! it.ultimaCombinacion()) {
        combinacion=it.siguienteCombinacion();
        for (int i = 0; i < argc - 1; i++) {
                if (combinacion[i] == 1){
                    cout << argv[i + 1]<< " " ;
                } 
        }
        cout<<endl;
    }
    return 0;
}


